# 4.5: RecyclerView

* Task 1: Create a new project and dataset -->*(Project: RecyclerView)*
* Task 2: Create a RecyclerView -->*(Project: RecyclerView)*
* Task 3: Make the list interactive -->*(Project: RecyclerView)*
* Coding challenges -->*(Project: RecyclerViewCC)*
* Homework -->*(Project: RecipesRecyclerView)*
